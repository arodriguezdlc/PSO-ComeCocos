

void * caracter(void * car);

void creaHilosKb(MOVING * a);
