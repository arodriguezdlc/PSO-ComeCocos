void jugador (MAPA * mapa, int cambiocontroles, char controlesj1[4], int j, char mov);//se le pasa el mapa, si se cambian los controles, los controles y el numero de jugador que es
