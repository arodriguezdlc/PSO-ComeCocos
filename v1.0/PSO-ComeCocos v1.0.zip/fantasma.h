//Funciones de fantasma.
void fantasma(MAPA * mapa, int i, int * cla);
int comprueba(int *posibles, int i, MAPA * mapa);
