int creaSemaforos(MAPA * mapa);
void eliminaSemaforos(MAPA * mapa, int primeraVez);
void subirSemaforos(MAPA * mapa);