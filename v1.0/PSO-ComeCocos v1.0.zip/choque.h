int choque(MAPA * mapa, MAPAANT * mapaAnt, int i, int j);
void guardamapa(MAPA * mapa, MAPAANT * mapaAnt);
